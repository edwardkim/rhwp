"""Reproduce issue 6701 baseline measurements; run from the repository root.
Usage: python measure_anchors.py <sweep-svg> <hancom.pdf>
PDF points are converted to physical 96 dpi; no page-box normalization.
"""
import json,re,sys,xml.etree.ElementTree as ET
import pymupdf
I=(1,0,0,1,0,0)
def mul(a,b):
 A,B,C,D,E,F=a;g,h,i,j,k,l=b
 return (A*g+C*h,B*g+D*h,A*i+C*j,B*i+D*j,A*k+C*l+E,B*k+D*l+F)
def transform(s):
 m=I
 for name,args in re.findall(r'(\w+)\(([^)]*)\)',s):
  v=[float(x) for x in re.findall(r'[-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?',args)]
  if name=='translate':t=(1,0,0,1,v[0],v[1] if len(v)>1 else 0)
  elif name=='scale':t=(v[0],0,0,v[1] if len(v)>1 else v[0],0,0)
  elif name=='matrix':t=tuple(v)
  else:raise ValueError((name,args))
  m=mul(m,t)
 return m
lines={}
def walk(n,parent=I):
 m=mul(parent,transform(n.get('transform','')))
 if n.tag.split('}')[-1]=='text':
  x=float(n.get('x','0'));y=float(n.get('y','0'));a,b,c,d,e,f=m
  lines.setdefault(round(b*x+d*y+f,3),[]).append((a*x+c*y+e,''.join(n.itertext())))
 for child in n:walk(child,m)
walk(ET.parse(sys.argv[1]).getroot())
normalize=lambda s:re.sub(r'\s+','',s)
svg={normalize(''.join(s for x,s in sorted(nodes))):y for y,nodes in lines.items()}
pdf=pymupdf.open(sys.argv[2]);page=pdf[25];pdf_lines={}
for b in page.get_text('dict')['blocks']:
 for l in b.get('lines',[]):
  spans=l['spans'];pdf_lines[normalize(''.join(s['text'] for s in spans))]=spans[0]['origin'][1]*4/3
anchors=['문의처','(www.lh.or.kr)','2022.07.27','부천시','한국토지주택공사인천지역본부','’']
def find(mapping,anchor):
 if anchor in mapping:return mapping[anchor]
 candidates=[v for k,v in mapping.items() if k.startswith(anchor)]
 assert len(candidates)==1,(anchor,candidates)
 return candidates[0]
rows=[dict(anchor=a,pdf_y=round(find(pdf_lines,a),3),svg_y=find(svg,a),delta=round(find(svg,a)-find(pdf_lines,a),3)) for a in anchors]
print(json.dumps({'units':'96 dpi physical pixels, PDF points * 4/3','svg':sys.argv[1],'pdf':sys.argv[2],'anchors':rows},ensure_ascii=False,indent=2))
