import json, os, subprocess, time
from pathlib import Path
r=Path('/private/tmp/rhwp-issue-6706-20260915'); target='/Users/tsjang/rhwp/target/issue-6706-20260915'
phases=[
('clippy-wasm',['cargo','clippy','--locked','-p','rhwp','--lib','--target','wasm32-unknown-unknown','--target-dir',target,'--','-D','warnings']),
('workspace-build',['cargo','build','--locked','--workspace','--target-dir',target]),
('clippy-workspace',['cargo','clippy','--locked','--workspace','--all-targets','--target-dir',target,'--','-D','warnings']),
('full',['cargo','nextest','run','--locked','--cargo-profile','release-test','--target-dir',target,'--tests','--test-threads','8','--no-fail-fast']),
('skia-lib',['cargo','test','--locked','--profile','release-test','--target-dir',target,'--features','native-skia','--lib','--','--test-threads','8']),
('skia-picture',['node','scripts/run-rust-test.mjs','issue_2225_missing_picture_placeholder','--','--cargo-profile','release-test','--target-dir',target,'--features','native-skia']),
('skia-pdf',['node','scripts/run-rust-test.mjs','render_p37_direct_pdf_export','--','--cargo-profile','release-test','--target-dir',target,'--features','native-skia']),
('wasm-build',['scripts/wasm-pack-locked.sh','--target','web','--out-dir',str(r/'wasm-pkg')]),
('fmt',['cargo','fmt','--all','--','--check']),
('manifest',['node','scripts/rust-test-suite-manifest.mjs','--check']),
]
state={'phases':[]};env=dict(os.environ,CARGO_TARGET_DIR=target)
for name,cmd in phases:
 entry={'name':name,'command':cmd,'started':time.time(),'status':'running'};state['phases'].append(entry);(r/'validation-state.json').write_text(json.dumps(state,indent=2));print('START',name,flush=True)
 with (r/f'{name}.log').open('w') as out:code=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=env).returncode
 entry.update(status='passed' if code==0 else 'failed',exit_code=code,seconds=time.time()-entry['started']);(r/'validation-state.json').write_text(json.dumps(state,indent=2));print('END',name,code,flush=True)
 if code:raise SystemExit(code)
