import importlib.util, pathlib, sys
spec = importlib.util.spec_from_file_location('ovr', pathlib.Path.cwd() / 'tools/object_visual_regression.py')
ovr = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ovr)
ovr.RHWP = pathlib.Path(sys.argv.pop(1))
raise SystemExit(ovr.main())
