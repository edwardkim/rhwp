# HWP 2024 MCP client 설정

이 package는 사용자 PC의 HWP/HWPX 파일을 Windows Hancom Office 2024 HTTP MCP service로
업로드하고 변환 결과를 다시 사용자 PC에 저장한다. server와 공유 폴더를 사용하지 않는다.
변환은 원격 MCP server에서 수행되며 이 client만으로는 변환할 수 없다. 외부 npm dependency는 없다.

## 환경 파일

`.env.local.example`을 Git 밖의 비공개 경로에 복사하고 관리자가 제공한 endpoint와 token을
입력한다. token과 실제 server 주소는 Git, issue, PR, 공개 문서와 로그에 기록하지 않는다.

## 명령

```text
hwp2024-mcp-bridge --help
hwp2024-mcp-convert --help
```

작은 문서는 `hwp2024-mcp-convert convert`, 큰 문서는 `start`, `status`, `download` 순서로
처리한다. 입력과 출력 경로는 client PC의 local 경로다. 자세한 사용법은 rhwp 저장소의
`mydocs/manual/mcp_hwp2024Convert_usage.md`를 따른다.
