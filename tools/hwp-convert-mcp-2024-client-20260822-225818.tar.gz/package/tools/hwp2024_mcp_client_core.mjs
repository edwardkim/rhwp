import { createHash, randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, statSync } from "node:fs";
import { link, rm, writeFile } from "node:fs/promises";
import path from "node:path";

const latestProtocolVersion = "2025-11-25";
const supportedProtocolVersions = new Set([latestProtocolVersion, "2025-06-18", "2025-03-26", "2024-11-05", "2024-10-07"]);

function parseSseMessages(text) {
  const messages = [];
  for (const block of text.replaceAll("\r\n", "\n").split(/\n\n+/)) {
    const data = block.split("\n")
      .filter((line) => line.startsWith("data:"))
      .map((line) => line.slice(5).replace(/^ /, ""))
      .join("\n");
    if (!data || data === "[DONE]") continue;
    messages.push(JSON.parse(data));
  }
  return messages;
}

async function responseMessages(response) {
  const text = await response.text();
  if (!text.trim()) return [];
  const contentType = String(response.headers.get("content-type") || "").toLowerCase();
  if (contentType.includes("text/event-stream")) return parseSseMessages(text);
  const parsed = JSON.parse(text);
  return Array.isArray(parsed) ? parsed : [parsed];
}

class HttpMcpSession {
  constructor(config) {
    this.endpoint = config.endpoint;
    this.authToken = config.authToken;
    this.sessionId = null;
    this.protocolVersion = null;
    this.nextId = 1;
  }

  headers({ json = true } = {}) {
    const headers = {
      Accept: "application/json, text/event-stream",
      Authorization: `Bearer ${this.authToken}`,
    };
    if (json) headers["Content-Type"] = "application/json";
    if (this.sessionId) headers["Mcp-Session-Id"] = this.sessionId;
    if (this.protocolVersion) headers["Mcp-Protocol-Version"] = this.protocolVersion;
    return headers;
  }

  async post(message, timeoutMilliseconds) {
    const response = await fetch(this.endpoint, {
      method: "POST",
      headers: this.headers(),
      body: JSON.stringify(message),
      signal: AbortSignal.timeout(timeoutMilliseconds),
    });
    this.sessionId ||= response.headers.get("mcp-session-id");
    if (!response.ok) {
      await response.body?.cancel().catch(() => undefined);
      throw new Error(`HTTP MCP request failed with status ${response.status}`);
    }
    if (response.status === 202) {
      await response.body?.cancel().catch(() => undefined);
      return null;
    }
    const messages = await responseMessages(response);
    if (!("id" in message)) return null;
    const result = messages.find((candidate) => candidate?.id === message.id);
    if (!result) throw new Error("HTTP MCP response did not contain the requested JSON-RPC id");
    if (result.error) throw new Error(result.error.message || "remote JSON-RPC request failed");
    return result.result;
  }

  async request(method, params, timeoutMilliseconds) {
    const id = this.nextId;
    this.nextId += 1;
    return this.post({ jsonrpc: "2.0", id, method, params }, timeoutMilliseconds);
  }

  async notification(method, params = {}) {
    await this.post({ jsonrpc: "2.0", method, params }, 30_000);
  }

  async connect() {
    const result = await this.request("initialize", {
      protocolVersion: latestProtocolVersion,
      capabilities: {},
      clientInfo: { name: "hwp-convert-mcp-2024-client", version: "0.8.0" },
    }, 30_000);
    if (!result?.protocolVersion || !supportedProtocolVersions.has(result.protocolVersion)) {
      throw new Error("HTTP MCP server negotiated an unsupported protocol version");
    }
    if (!this.sessionId) throw new Error("HTTP MCP server did not return a session id");
    this.protocolVersion = result.protocolVersion;
    await this.notification("notifications/initialized");
  }

  async callTool(name, args, timeoutMilliseconds) {
    return this.request("tools/call", { name, arguments: args }, timeoutMilliseconds);
  }

  async close() {
    if (!this.sessionId) return;
    try {
      const response = await fetch(this.endpoint, {
        method: "DELETE",
        headers: this.headers({ json: false }),
        signal: AbortSignal.timeout(30_000),
      });
      await response.body?.cancel().catch(() => undefined);
    } catch {
      // The conversion result is already delivered; session cleanup is best effort.
    } finally {
      this.sessionId = null;
    }
  }
}

function environmentFile(filePath) {
  const resolved = path.resolve(String(filePath || ""));
  if (!existsSync(resolved) || !statSync(resolved).isFile()) throw new Error(`environment file does not exist: ${resolved}`);
  const values = {};
  for (const line of readFileSync(resolved, "utf8").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const separator = trimmed.indexOf("=");
    if (separator < 1) continue;
    const key = trimmed.slice(0, separator).trim();
    let value = trimmed.slice(separator + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    values[key] = value;
  }
  return values;
}

export function clientConfig(options = {}, environment = process.env) {
  const fileValues = options.envFile ? environmentFile(options.envFile) : {};
  const serverUrl = String(options.serverUrl || fileValues.HWP2024_MCP_SERVER_URL || environment.HWP2024_MCP_SERVER_URL || "http://127.0.0.1:3001/mcp").trim();
  const authToken = String(options.authToken || fileValues.HWP2024_MCP_AUTH_TOKEN || environment.HWP2024_MCP_AUTH_TOKEN || "").trim();
  if (!authToken) throw new Error("HWP2024_MCP_AUTH_TOKEN or --auth-token is required");
  const endpoint = new URL(serverUrl);
  if (!["http:", "https:"].includes(endpoint.protocol)) throw new Error("MCP server URL must use HTTP or HTTPS");
  return { endpoint, authToken };
}

export function prepareConversionRequest(args) {
  const inputPath = path.resolve(String(args.input_path || ""));
  if (!existsSync(inputPath) || !statSync(inputPath).isFile()) throw new Error(`input_path does not exist or is not a file: ${inputPath}`);
  const extension = path.extname(inputPath).toLowerCase();
  if (![".hwp", ".hwpx"].includes(extension)) throw new Error("input_path must end in .hwp or .hwpx");
  const target = String(args.target || "pdf").toLowerCase();
  if (!["pdf", "hwp", "hwpx"].includes(target)) throw new Error("target must be pdf, hwp, or hwpx");
  if (extension === ".hwpx" && target === "hwpx") throw new Error("unsupported target 'hwpx' for .hwpx input");
  const timeoutSeconds = args.timeout_seconds ?? 600;
  if (!Number.isInteger(timeoutSeconds) || timeoutSeconds < 10 || timeoutSeconds > 1800) {
    throw new Error("timeout_seconds must be an integer between 10 and 1800");
  }
  const outputFilename = args.output_filename || `${path.basename(inputPath, extension)}-hwp2024.${target}`;
  if (outputFilename !== path.basename(outputFilename) || /[\\/]/.test(outputFilename)) throw new Error("output_filename must be a filename, not a path");
  if (path.extname(outputFilename).toLowerCase() !== `.${target}`) throw new Error(`output_filename must end in .${target}`);
  return {
    inputPath,
    outputFilename,
    target,
    timeoutSeconds,
    remoteArguments: {
      input_filename: path.basename(inputPath),
      input_blob: readFileSync(inputPath).toString("base64"),
      target,
      output_filename: outputFilename,
      options: { timeout_seconds: timeoutSeconds },
    },
  };
}

export function parseRemoteResult(toolResult) {
  const text = toolResult?.content?.find((item) => item.type === "text")?.text;
  if (!text) throw new Error("remote MCP tool returned no JSON metadata");
  const result = JSON.parse(text);
  if (toolResult.isError) throw new Error(result.error || "remote MCP request failed");
  return result;
}

export async function callRemoteTool(config, name, args, timeoutMilliseconds) {
  const session = new HttpMcpSession(config);
  await session.connect();
  try {
    return await session.callTool(name, args, timeoutMilliseconds);
  } finally {
    await session.close();
  }
}

export async function publishResource(toolResult, result, outputDirectory, requestedFilename) {
  const resource = toolResult?.content?.find((item) => item.type === "resource")?.resource;
  if (!resource?.blob) throw new Error("remote MCP tool returned no result resource blob");
  const outputBuffer = Buffer.from(resource.blob, "base64");
  const sha256 = createHash("sha256").update(outputBuffer).digest("hex");
  if (outputBuffer.length === 0 || outputBuffer.length !== result.size || sha256 !== result.sha256) {
    throw new Error("remote result resource failed size or SHA-256 verification");
  }
  const outputDir = path.resolve(String(outputDirectory || ""));
  if (existsSync(outputDir) && !statSync(outputDir).isDirectory()) throw new Error("output_dir must be a directory path");
  mkdirSync(outputDir, { recursive: true });
  const outputFilename = requestedFilename || result.output_filename;
  if (outputFilename !== path.basename(outputFilename) || /[\\/]/.test(outputFilename)) throw new Error("output_filename must be a filename, not a path");
  if (path.extname(outputFilename).toLowerCase() !== `.${result.target}`) throw new Error(`output_filename must end in .${result.target}`);
  const outputPath = path.join(outputDir, outputFilename);
  if (existsSync(outputPath)) throw new Error("The output file already exists; choose a new output_filename");
  const partialPath = path.join(outputDir, `.${outputFilename}.${randomUUID()}.partial`);
  try {
    await writeFile(partialPath, outputBuffer, { flag: "wx" });
    await link(partialPath, outputPath);
  } finally {
    await rm(partialPath, { force: true });
  }
  return { outputPath, outputFilename, size: outputBuffer.length, sha256 };
}

export function validateJobId(value) {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(value || ""))) {
    throw new Error("job_id must be a UUID returned by start");
  }
  return String(value);
}
