#!/usr/bin/env node
import { createInterface } from "node:readline";
import {
  callRemoteTool,
  clientConfig,
  parseRemoteResult,
  prepareConversionRequest,
  publishResource,
  validateJobId,
} from "./hwp2024_mcp_client_core.mjs";

const latestProtocolVersion = "2025-11-25";
const supportedProtocolVersions = new Set([latestProtocolVersion, "2025-06-18", "2025-03-26", "2024-11-05", "2024-10-07"]);
const conversionProperties = {
  input_path: { type: "string", minLength: 1, description: "Local .hwp or .hwpx path on the MCP client machine." },
  target: { type: "string", enum: ["pdf", "hwp", "hwpx"], default: "pdf" },
  output_filename: { type: "string", minLength: 1 },
  timeout_seconds: { type: "integer", minimum: 10, maximum: 1800, default: 600 },
};
const tools = [
  {
    name: "convert_local_document",
    title: "Convert a local HWP/HWPX through the Windows service",
    description: "Upload a client-local file to the remote HWP 2024 MCP server, convert it, verify the returned blob, and save it locally.",
    inputSchema: {
      type: "object",
      properties: { ...conversionProperties, output_dir: { type: "string", minLength: 1 } },
      required: ["input_path", "output_dir"],
      additionalProperties: false,
    },
  },
  {
    name: "start_local_document_conversion",
    title: "Start a local HWP/HWPX conversion",
    description: "Upload a client-local file to the remote HWP 2024 MCP server and return an asynchronous job ID.",
    inputSchema: {
      type: "object",
      properties: conversionProperties,
      required: ["input_path"],
      additionalProperties: false,
    },
  },
  {
    name: "get_local_conversion_status",
    title: "Get HWP 2024 conversion status",
    description: "Query a remote conversion job without exposing server-local paths.",
    inputSchema: {
      type: "object",
      properties: { job_id: { type: "string", format: "uuid" } },
      required: ["job_id"],
      additionalProperties: false,
    },
  },
  {
    name: "save_local_conversion_result",
    title: "Save an HWP 2024 conversion result locally",
    description: "Download a succeeded job, verify its byte count and SHA-256, and save it on the MCP client machine.",
    inputSchema: {
      type: "object",
      properties: {
        job_id: { type: "string", format: "uuid" },
        output_dir: { type: "string", minLength: 1 },
        output_filename: { type: "string", minLength: 1 },
      },
      required: ["job_id", "output_dir"],
      additionalProperties: false,
    },
  },
];

function usage() {
  return "Usage: HWP2024_MCP_SERVER_URL=http://server:3001/mcp HWP2024_MCP_AUTH_TOKEN=... hwp2024-mcp-bridge";
}

function parseArgs(argv) {
  const options = {};
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--help" || arg === "-h") return { help: true };
    if (!["--server-url", "--auth-token"].includes(arg) || index + 1 >= argv.length) {
      throw new Error(`unknown or incomplete argument: ${arg}`);
    }
    options[arg === "--server-url" ? "serverUrl" : "authToken"] = argv[index + 1];
    index += 1;
  }
  return options;
}

function assertArguments(args, allowed, required) {
  if (!args || typeof args !== "object" || Array.isArray(args)) throw new Error("tool arguments must be an object");
  for (const key of Object.keys(args)) {
    if (!allowed.includes(key)) throw new Error(`unsupported argument: ${key}`);
  }
  for (const key of required) {
    if (args[key] === undefined || args[key] === "") throw new Error(`${key} is required`);
  }
}

async function invokeTool(config, name, args) {
  if (name === "convert_local_document") {
    assertArguments(args, [...Object.keys(conversionProperties), "output_dir"], ["input_path", "output_dir"]);
    const request = prepareConversionRequest(args);
    const remote = await callRemoteTool(config, "convert_document", request.remoteArguments, (request.timeoutSeconds + 120) * 1000);
    const server = parseRemoteResult(remote);
    const saved = await publishResource(remote, server, args.output_dir, args.output_filename);
    return { status: "success", input_path: request.inputPath, output_path: saved.outputPath, target: request.target, size: saved.size, sha256: saved.sha256, server };
  }
  if (name === "start_local_document_conversion") {
    assertArguments(args, Object.keys(conversionProperties), ["input_path"]);
    const request = prepareConversionRequest(args);
    return parseRemoteResult(await callRemoteTool(config, "start_conversion", request.remoteArguments, 120_000));
  }
  if (name === "get_local_conversion_status") {
    assertArguments(args, ["job_id"], ["job_id"]);
    const jobId = validateJobId(args.job_id);
    return parseRemoteResult(await callRemoteTool(config, "get_conversion_status", { job_id: jobId }, 120_000));
  }
  if (name === "save_local_conversion_result") {
    assertArguments(args, ["job_id", "output_dir", "output_filename"], ["job_id", "output_dir"]);
    const jobId = validateJobId(args.job_id);
    const remote = await callRemoteTool(config, "get_conversion_result", { job_id: jobId }, 120_000);
    const server = parseRemoteResult(remote);
    const saved = await publishResource(remote, server, args.output_dir, args.output_filename);
    return { status: "success", job_id: jobId, output_path: saved.outputPath, output_filename: saved.outputFilename, size: saved.size, sha256: saved.sha256, server };
  }
  throw new Error(`unknown tool: ${name}`);
}

async function toolResult(config, name, args) {
  try {
    const result = await invokeTool(config, name, args);
    return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }], isError: false };
  } catch (error) {
    return {
      content: [{ type: "text", text: JSON.stringify({ status: "failed", error: error instanceof Error ? error.message : String(error) }, null, 2) }],
      isError: true,
    };
  }
}

function write(message) {
  process.stdout.write(`${JSON.stringify(message)}\n`);
}

async function handleRequest(config, message) {
  if (!message || message.jsonrpc !== "2.0" || typeof message.method !== "string") {
    if (message?.id !== undefined) write({ jsonrpc: "2.0", id: message.id, error: { code: -32600, message: "Invalid Request" } });
    return;
  }
  if (message.method.startsWith("notifications/")) return;
  if (message.id === undefined) return;
  if (message.method === "initialize") {
    const requested = message.params?.protocolVersion;
    const protocolVersion = supportedProtocolVersions.has(requested) ? requested : latestProtocolVersion;
    write({
      jsonrpc: "2.0",
      id: message.id,
      result: {
        protocolVersion,
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: "hwp-convert-mcp-2024-client-bridge", version: "0.8.0" },
        instructions: "Uploads client-local HWP/HWPX files to the configured remote HWP 2024 MCP server.",
      },
    });
    return;
  }
  if (message.method === "ping") {
    write({ jsonrpc: "2.0", id: message.id, result: {} });
    return;
  }
  if (message.method === "tools/list") {
    write({ jsonrpc: "2.0", id: message.id, result: { tools } });
    return;
  }
  if (message.method === "tools/call") {
    write({ jsonrpc: "2.0", id: message.id, result: await toolResult(config, message.params?.name, message.params?.arguments || {}) });
    return;
  }
  write({ jsonrpc: "2.0", id: message.id, error: { code: -32601, message: "Method not found" } });
}

async function main() {
  const options = parseArgs(process.argv.slice(2));
  if (options.help) {
    console.log(usage());
    return;
  }
  const config = clientConfig(options);
  const input = createInterface({ input: process.stdin, crlfDelay: Infinity });
  for await (const line of input) {
    if (!line.trim()) continue;
    try {
      await handleRequest(config, JSON.parse(line));
    } catch (error) {
      process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
    }
  }
}

main().catch((error) => {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
});
